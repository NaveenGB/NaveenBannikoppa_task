//
//  ViewController.swift
//  NaveenBannikoppa_Task
//
//  Created by H533826 on 05/12/24.
//

import UIKit

import Foundation

import UIKit
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var activeTokens: UIStackView!
    @IBOutlet weak var activeCoins: UIStackView!
    
    let cellReuseIdentifier = "cell"
    
    @IBOutlet var tableView: UITableView!
    
    private let viewModel: HomeViewModel

    required init(viewModel: HomeViewModel) {
        self.viewModel = viewModel
        super.init()
        self.viewModel.delegate = self
        navigationItem.largeTitleDisplayMode = .always
    }

    required init?(coder aDecoder: NSCoder) {
        viewModel = HomeViewModel()
        super.init(coder: aDecoder)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationController?.navigationBar.barTintColor = UIColor.green
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "CustomCell", bundle: nil), forCellReuseIdentifier: "CustomCell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        viewModel.loadData()
        configureLayout()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    // number of rows in table view
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return viewModel.numberOfItems
    }
    
    // create a cell for each table view row
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell:CustomCell = self.tableView.dequeueReusableCell(withIdentifier: "CustomCell", for: indexPath) as! CustomCell
        
        cell.myCellLabel.text = viewModel.filteredCoins[indexPath.row].name
        cell.coinShortName.text = viewModel.filteredCoins[indexPath.row].symbol
        switch viewModel.coins[indexPath.row].is_new && viewModel.coins[indexPath.row].is_active {
        case true:
            cell.myView.image = viewModel.filteredCoins[indexPath.row].is_new ? UIImage(named: "coin_active") : UIImage(named: "coin_active")
        case false:
            cell.myView.image = viewModel.filteredCoins[indexPath.row].is_new ? UIImage(named: "coin_inactive") : UIImage(named: "coin_inactive")
        }
        return cell
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("You tapped cell number \(indexPath.row).")
    }
    
    func configureLayout() {
        view.addSubview(tableView)
        //searchBar.isHidden = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 3) { [unowned self] in
                tableView.reloadData()
            }
    }
    
    //Search filter implementaiton
    @IBAction func searchFilter(_ sender: UIButton) {
        switch sender.tag {
        case 1:
            viewModel.filteredCoins = viewModel.coins.filter { $0.is_active == true }
        case 2:
            viewModel.filteredCoins = viewModel.coins.filter { $0.is_active == false}
        case 3:
            viewModel.filteredCoins = viewModel.coins.filter { $0.type == "token"}
        case 4:
            viewModel.filteredCoins = viewModel.coins.filter { $0.type == "coin"}
        case 5:
            viewModel.filteredCoins = viewModel.coins.filter { $0.is_new == true }
        default:
            viewModel.filteredCoins = viewModel.coins
        }
        tableView.reloadData()
    }
    
}

//Search bar implementation
extension ViewController: UISearchBarDelegate {
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        if searchText.isEmpty {
            viewModel.filteredCoins = viewModel.coins
            tableView.reloadData()
        } else {
            viewModel.filteredCoins = viewModel.coins.filter { $0.name.lowercased().contains(searchText.lowercased()) || $0.symbol.lowercased().contains(searchText.lowercased()) }
            tableView.reloadData()
        }
    }
}

// MARK: RequestDelegate
extension ViewController: RequestDelegate {
    func didUpdate(with state: ViewState) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            switch state {
            case .idle:
                break
            case .success:
                self.tableView.setContentOffset(.zero, animated: true)
                self.tableView.reloadData()
                //self.stopLoading()
            case .error(let error):
                print(error)
            case .loading:
                print("Loading")
            }
        }
    }
}
