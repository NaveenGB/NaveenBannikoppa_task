//
//  HomeViewModel.swift
//  NaveenBannikoppa_Task
//
//

import Foundation


enum Types: Int, CaseIterable {
    case all
    case inactive
    case active
    case new

    var name: String {
        switch self {
        case .all: return "All"
        case .inactive: return "Inactive"
        case .active: return "Active"
        case .new: return "New"
        }
    }
    
}

final class HomeViewModel {
    weak var delegate: RequestDelegate?
    private var state: ViewState {
        didSet {
            self.delegate?.didUpdate(with: state)
        }
    }
    
    var coins: [Items] = []
    var filteredCoins: [Items] = []
    var selectedType: Types = .all {
        didSet {
            self.filterData()
        }
    }
    
    init() {
        self.state = .idle
    }
}

// MARK: - DataSource
extension HomeViewModel {
    var numberOfItems: Int {
        filteredCoins.count
    }

    func getInfo(for indexPath: IndexPath) -> (name: String, symbol: String, is_new: Bool, is_active: Bool, type: String) {
        let coin = filteredCoins[indexPath.row]
        return (name: coin.name, symbol: coin.symbol, is_new: coin.is_new, is_active: coin.is_active, type: coin.type)
    }
}

// MARK: - Service
extension HomeViewModel {
    func loadData() {
        self.state = .loading
        CoinService.fetchData { result in
            switch result {
            case let .success(coins):
                self.coins = coins
                self.filteredCoins = coins
                self.state = .success
            case let .failure(error):
                self.coins = []
                self.filteredCoins = []
                self.state = .error(error)
            }
        }
    }

    func filterByType(type: Types) {
        self.selectedType = type
    }

    func selectedTypeName() -> String {
        self.selectedType.name
    }
}


// MARK: - Filter Data
private extension HomeViewModel {
    func filterData() {
        guard selectedType != .all else {
            self.filteredCoins = coins
            self.state = .success
            return
        }

        guard selectedType != .inactive else {
            self.filteredCoins = self.coins.filter { !$0.type.lowercased().contains(Types.active.name.lowercased()) && !$0.type.lowercased().contains(Types.new.name.lowercased()) }
            self.state = .success
            return
        }

        self.filteredCoins = self.coins.filter { $0.type.lowercased().contains(self.selectedType.name.lowercased()) }
        self.state = .success
    }
}
