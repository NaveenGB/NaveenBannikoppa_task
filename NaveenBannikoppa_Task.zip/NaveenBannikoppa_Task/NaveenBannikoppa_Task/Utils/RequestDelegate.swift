//
//  RequestDelegate.swift
//  NaveenBannikoppa_Task
//
//  Created by H533826 on 05/12/24.
//

import Foundation

protocol RequestDelegate: AnyObject {
    func didUpdate(with state: ViewState)
}
