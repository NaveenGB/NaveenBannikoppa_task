//
//  State.swift
//  NaveenBannikoppa_Task
//
//  Created by H533826 on 05/12/24.
//

import Foundation

enum ViewState {
    case idle
    case loading
    case success
    case error(Error)
}
