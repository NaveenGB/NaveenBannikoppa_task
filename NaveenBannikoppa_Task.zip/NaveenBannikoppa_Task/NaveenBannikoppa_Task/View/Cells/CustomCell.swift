//
//  CustomCell.swift
//
//

import UIKit
class CustomCell: UITableViewCell {
    @IBOutlet weak var myView: UIImageView!
    @IBOutlet weak var myCellLabel: UILabel!
    @IBOutlet weak var coinShortName: UILabel!
}
