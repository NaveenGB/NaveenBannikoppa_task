//
//  Items.swift
//  Ticker
//
//  Created by H533826 on 04/12/24.
//

import Foundation

// Example model
struct Items: Decodable {
    let name: String
    let symbol: String
    let is_new: Bool
    let is_active: Bool
    let type: String
}
