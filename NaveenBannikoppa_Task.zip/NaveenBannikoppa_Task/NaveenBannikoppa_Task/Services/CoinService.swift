//
//  CoinService.swift
//  NaveenBannikoppa_Task
//
//

import Foundation

final class CoinService {
    static func fetchData(completion: @escaping (Result<[Items], Error>) -> Void) {
        guard Reachability.isConnectedToNetwork(),
              let url = URL(string: "https://37656be98b8f42ae8348e4da3ee3193f.api.mockbin.io") else {
                  completion(.failure(CustomError.noConnection))
                  return
              }
        
        // Create a URLSession data task
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            // Check for errors
            if let error = error {
                print("Error: \(error.localizedDescription)")
                return
            }
            
            // Check if the response is valid
            guard let data = data else {
                print("No data received")
                return
            }
            
            // Attempt to decode the JSON data into an array of items
            do {
                let decoder = JSONDecoder()
                let items = try decoder.decode([Items].self, from: data)
                completion(.success(items))
                // Update UI on the main thread (if needed)
                DispatchQueue.main.async {
                    //self.updateUI(with: items)
                }
            } catch {
                print("Error decoding JSON: \(String(describing: error))")
            }
        }
        
        // Start the data task
        task.resume()
    }
}
