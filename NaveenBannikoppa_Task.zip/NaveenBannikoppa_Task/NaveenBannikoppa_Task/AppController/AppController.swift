//
//  AppController.swift
//  NaveenBannikoppa_Task
//
//
import UIKit
class AppController: UIViewController {
    public init() {
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override public func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
    }
}
extension AppController {
    func startLoading() {
        self.view.isUserInteractionEnabled = false
    }

    func stopLoading() {
        self.view.isUserInteractionEnabled = true
    }
}
