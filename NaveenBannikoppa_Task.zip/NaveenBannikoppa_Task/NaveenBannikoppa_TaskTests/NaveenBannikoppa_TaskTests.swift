//
//  NaveenBannikoppa_TaskTests.swift
//  NaveenBannikoppa_TaskTests
//
//  Created by H533826 on 05/12/24.
//

import Testing
@testable import NaveenBannikoppa_Task

struct NaveenBannikoppa_TaskTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

    @Test func testViewState() {
        let viewState = ViewState.idle
        switch viewState {
        case .idle:
            print("Idle")
        case .loading:
            print("Loading")
        case .success:
            print("Success")
        case .error(let error):
            print("Error: \(error)")
        }
    }
    
    @Test func testReachability() {
        let isConnected = Reachability.isConnectedToNetwork()
        print("Is connected: \(isConnected)")
    }
    
    @Test func testRequestDelegate() {
        let requestDelegate = RequestDelegate.self
        print("Request Delegate: \(requestDelegate)")
    }
}
